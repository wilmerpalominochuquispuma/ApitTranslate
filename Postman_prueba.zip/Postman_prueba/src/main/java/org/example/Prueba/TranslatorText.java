package org.example.Prueba;

import java.io.IOException;
import java.lang.String;
import com.google.gson.JsonParser;

import com.google.gson.*;
import okhttp3.*;
import org.example.connection.DatabaseConnection;


public class TranslatorText {
    private static String key = "8c63315802814f75a38f9564366c6d2f";
    private static String location = "eastus";

    OkHttpClient client = new OkHttpClient();

    public String Post() throws IOException {
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "[{\"Text\": \"I would really like to drive your car around the block a few times!\"}]");
        Request request = new Request.Builder()
                .url("https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&from=en&to=it&to=es")
                .post(body)
                .addHeader("Ocp-Apim-Subscription-Key", key)
                .addHeader("Ocp-Apim-Subscription-Region", location)
                .addHeader("Content-type", "application/json")
                .build();
        Response response = client.newCall(request).execute();
        return response.body().string();
    }

    public static String prettify(String json_text) {
        JsonParser parser = new JsonParser();
        JsonElement json = parser.parse(json_text);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(json);
    }

    public static void main(String[] args) {
        try {
            TranslatorText translateRequest = new TranslatorText();
            String response = translateRequest.Post();
            System.out.println(prettify(response));
            // Verificar la conexión a la base de datos
            DatabaseConnection.getConnection();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
