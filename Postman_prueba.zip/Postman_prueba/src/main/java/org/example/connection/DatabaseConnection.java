package org.example.connection;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:h2:~/test"; // URL de conexión a la base de datos H2
    private static final String USER = "sa"; // Usuario por defecto de H2
    private static final String PASSWORD = ""; // Contraseña por defecto de H2

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.h2.Driver"); // Cargar el controlador JDBC de H2
        } catch (ClassNotFoundException e) {
            System.out.println("No se pudo cargar el controlador JDBC: " + e.getMessage());
            e.printStackTrace();
        }
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD); // Establecer la conexión
            System.out.println("Conexión a la base de datos establecida correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
        return connection;
    }
}

